﻿namespace CS3110_Module_8_Group
{
    public enum PlayMode
    {
        Delay,
        Pause,
        NoDelay
    }
}
