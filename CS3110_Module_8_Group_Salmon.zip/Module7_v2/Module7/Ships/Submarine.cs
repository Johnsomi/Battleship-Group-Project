﻿using System;

namespace CS3110_Module_8_Group
{
    class Submarine : Ship
    {
        public Submarine() : base(3, ConsoleColor.Cyan, ShipTypes.Submarine)
        {
        }
    }
}
