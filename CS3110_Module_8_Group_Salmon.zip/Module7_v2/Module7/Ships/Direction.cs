﻿namespace CS3110_Module_8_Group
{
    public enum Direction
    {
        Horizontal,
        Vertical,
    }
}
