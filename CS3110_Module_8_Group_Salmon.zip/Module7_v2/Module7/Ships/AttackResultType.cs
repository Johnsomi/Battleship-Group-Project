﻿namespace CS3110_Module_8_Group
{
    public enum AttackResultType
    {
        Miss,
        Hit,
        Sank,
    }
}
