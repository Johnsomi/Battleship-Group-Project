﻿using System;

namespace CS3110_Module_8_Group
{
    class PatrolBoat : Ship
    {
        public PatrolBoat() : base(2, ConsoleColor.White, ShipTypes.PatrolBoat)
        {
        }

    }
}
