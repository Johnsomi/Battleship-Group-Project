﻿using System;

namespace CS3110_Module_8_Group
{ 
    class AircraftCarrier : Ship
    {
        public AircraftCarrier() : base(5, ConsoleColor.Blue, ShipTypes.AircraftCarrier)
        {

        }

    }
}
