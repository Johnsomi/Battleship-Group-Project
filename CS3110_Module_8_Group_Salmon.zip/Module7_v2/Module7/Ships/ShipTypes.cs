﻿namespace CS3110_Module_8_Group
{
    public enum ShipTypes
    {
        None,
        PatrolBoat,
        Submarine,
        Destroyer,
        AircraftCarrier,
        Battleship,
    }
}
