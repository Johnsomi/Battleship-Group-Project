﻿using System;

namespace CS3110_Module_8_Group
{
    class Destroyer : Ship
    {
        public Destroyer() : base(3, ConsoleColor.DarkRed, ShipTypes.Destroyer)
        {
        }
    }
}
