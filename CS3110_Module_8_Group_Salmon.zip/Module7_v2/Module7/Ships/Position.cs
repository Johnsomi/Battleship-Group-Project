﻿namespace CS3110_Module_8_Group
{
    public class Position
    {
        public int X;
        public int Y;
        public bool Hit;
        public Position(int x, int y)
        {
            X = x;
            Y = y;
            Hit = false;
        }
    }
}
