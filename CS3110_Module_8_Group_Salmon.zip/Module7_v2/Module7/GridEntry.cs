﻿namespace CS3110_Module_8_Group
{
    public class GridEntry
    {
        public bool Hit;
        public Ship Ship;
    }
}
