﻿namespace Module8
{
    public enum PlayMode
    {
        Delay,
        Pause,
        NoDelay
    }
}
