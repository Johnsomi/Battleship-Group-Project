﻿namespace Module8
{
    public class GridEntry
    {
        public bool Hit;
        public Ship Ship;
    }
}
