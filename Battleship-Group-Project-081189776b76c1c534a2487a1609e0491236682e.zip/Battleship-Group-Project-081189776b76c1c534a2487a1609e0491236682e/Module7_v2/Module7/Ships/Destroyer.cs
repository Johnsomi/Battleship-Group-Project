﻿using System;

namespace Module8
{
    class Destroyer : Ship
    {
        public Destroyer() : base(3, ConsoleColor.DarkRed, ShipTypes.Destroyer)
        {
        }
    }
}
