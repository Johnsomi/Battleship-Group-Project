﻿namespace Module8
{
    public enum ShipTypes
    {
        None,
        PatrolBoat,
        Submarine,
        Destroyer,
        AircraftCarrier,
        Battleship,
    }
}
