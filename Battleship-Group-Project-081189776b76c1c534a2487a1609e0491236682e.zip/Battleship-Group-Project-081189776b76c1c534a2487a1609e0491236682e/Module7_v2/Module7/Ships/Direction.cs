﻿namespace Module8
{
    public enum Direction
    {
        Horizontal,
        Vertical,
    }
}
