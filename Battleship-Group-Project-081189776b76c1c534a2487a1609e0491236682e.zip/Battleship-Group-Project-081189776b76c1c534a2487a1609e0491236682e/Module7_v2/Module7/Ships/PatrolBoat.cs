﻿using System;

namespace Module8
{
    class PatrolBoat : Ship
    {
        public PatrolBoat() : base(2, ConsoleColor.White, ShipTypes.PatrolBoat)
        {
        }

    }
}
