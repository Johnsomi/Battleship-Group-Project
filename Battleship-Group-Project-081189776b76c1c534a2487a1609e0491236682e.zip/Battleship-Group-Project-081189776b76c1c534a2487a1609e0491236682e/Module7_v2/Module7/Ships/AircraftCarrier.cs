﻿using System;

namespace Module8
{ 
    class AircraftCarrier : Ship
    {
        public AircraftCarrier() : base(5, ConsoleColor.Blue, ShipTypes.AircraftCarrier)
        {

        }

    }
}
