﻿namespace Module8
{
    public enum AttackResultType
    {
        Miss,
        Hit,
        Sank,
    }
}
