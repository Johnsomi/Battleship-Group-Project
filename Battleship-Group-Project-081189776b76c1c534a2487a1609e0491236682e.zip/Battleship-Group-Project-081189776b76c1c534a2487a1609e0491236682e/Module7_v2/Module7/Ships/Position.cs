﻿namespace Module8
{
    public class Position
    {
        public int X;
        public int Y;
        public bool Hit;
        public Position(int x, int y)
        {
            X = x;
            Y = y;
            Hit = false;
        }
    }
}
