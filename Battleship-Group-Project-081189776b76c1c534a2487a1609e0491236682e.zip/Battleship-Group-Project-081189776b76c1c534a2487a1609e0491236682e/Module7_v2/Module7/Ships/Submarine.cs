﻿using System;

namespace Module8
{
    class Submarine : Ship
    {
        public Submarine() : base(3, ConsoleColor.Cyan, ShipTypes.Submarine)
        {
        }
    }
}
